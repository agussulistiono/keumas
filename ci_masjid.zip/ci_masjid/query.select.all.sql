SELECT jenis_dana.`id_jenis`,jenis_dana.`jenisdana`,kategori_dana.`id_kategori`,kategori_dana.`kategori`,
transaksi.`id_transaksi`, transaksi.`pemasukan`,transaksi.`pengeluaran`, transaksi.`tanggal`, transaksi.`sumber_pemakai` 
FROM transaksi JOIN jenis_dana ON (transaksi.`id_jenis`=jenis_dana.`id_jenis`) 
JOIN kategori_dana ON(transaksi.`id_kategori`=kategori_dana.`id_kategori`) 
 