<?php 
	error_reporting(0);
	session_start();	
	
	include "config/koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author"      content="Sergey Pozhilov (GetTemplate.com)">
	
	<title>SIK - Masjid AL-FURQON</title>

	<link rel="shortcut icon" href="<?php echo base_url(); ?>assets/front/images/icon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/front/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/front/css/font-awesome.min.css">
	
	<link href="adminpage/bootstrap/css/bootstrap-table.css" rel="stylesheet">
	<!-- DataTables -->
	<link rel="stylesheet" href="adminpage/plugins/datatables/dataTables.bootstrap.css">
	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/front/css/bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/front/css/main.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="adminpage/plugins/datepicker/datepicker3.css">
	<!-- Daterange picker -->
	<link rel="stylesheet" href="adminpage/plugins/daterangepicker/daterangepicker.css">
	

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="<?php echo base_url(); ?>assets/front/js/html5shiv.js"></script>
	<script src="<?php echo base_url(); ?>assets/front/js/respond.min.js"></script>
	<![endif]-->
</head>

<body class="home" onload="myFunction()">
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				
						<a class="navbar-brand" href="?module=homeuser"><font color="#ff4500">SIK Masjid</font> <font color="#d3d3d3">Al-Mukhlisin</font></a>
					
			</div>
				<!--menu bar-->
					<div class="navbar-collapse collapse">
			<ul class="nav navbar-nav pull-right">
				<li class="<?php if($aktif == "homeuser"){ echo"active"; }?>"><a href="?module=homeuser">Home</a></li>

				<li class="dropdown <?php if(($aktif == "lap_kas") || ($aktif == "lap_donasi") || ($aktif == "lap_santunan")){ echo "active";}?>">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Kegiatan <b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li class="<?php if($aktif == "lap_kas"){ echo "active"; }?>"><a href="?module=lap_kas">Pengajian Mingguan</a></li>
						<li class="<?php if($aktif == "lap_donasi"){ echo "active"; }?>"><a href="?module=lap_donasi">Pengajian Harian</a></li>
						<li class="<?php if($aktif == "lap_santunan"){ echo "active"; }?>"><a href="?module=lap_santunan">Sholat Jum'at</a></li>
					</ul>
				</li>
				
				<li class="dropdown <?php if(($aktif == "lap_kas") || ($aktif == "lap_donasi") || ($aktif == "lap_santunan")){ echo "active";}?>">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Laporan <b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li class="<?php if($aktif == "lap_kas"){ echo "active"; }?>"><a href="?module=lap_kas">Laporan KAS</a></li>
						<li class="<?php if($aktif == "lap_donasi"){ echo "active"; }?>"><a href="?module=lap_donasi">Laporan Donasi</a></li>
						<li class="<?php if($aktif == "lap_santunan"){ echo "active"; }?>"><a href="?module=lap_santunan">Laporan Santunan</a></li>
					</ul>
				</li>
				
				<li class="<?php if(($aktif == "list") || ($aktif == "detail_d") || ($aktif == "detail_p")){ echo "active"; }?>"><a href="?module=list">List Data</a></li>
				
				<li class="<?php if($aktif == "donasi"){ echo "active"; }?>"><a href="?module=donasi">Donasi</a></li>
				
				<li class="dropdown <?php if(($aktif == "zakatmall") || ($aktif == "zakatuang") || ($aktif == "zakatdagangan") || ($aktif == "zakattanian") || ($aktif == "zakathewan") || ($aktif == "zakathartatemuan")){ echo "active";}?>">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Kalkulator Zakat <b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li class="<?php if($aktif == "zakatmall"){ echo "active"; }?>"><a href="?module=zakatmall">Zakat Emas & Perak</a></li>
						<li class="<?php if($aktif == "zakatuang"){ echo "active"; }?>"><a href="?module=zakatuang">Zakat Uang</a></li>
						<li class="<?php if($aktif == "zakatdagangan"){ echo "active"; }?>"><a href="?module=zakatdagangan">Zakat Perdagangan</a></li>
						<li class="<?php if($aktif == "zakattanian"){ echo "active"; }?>"><a href="?module=zakattanian">Zakat Pertanian</a></li>
						<li class="<?php if($aktif == "zakathewan"){ echo "active"; }?>"><a href="?module=zakathewan">Zakat Hewan Ternak</a></li>
						<li class="<?php if($aktif == "zakathartatemuan"){ echo "active"; }?>"><a href="?module=zakathartatemuan">Zakat Harta Temuan</a></li>
					</ul>
				</li>
				
				<li class="dropdown <?php if(($aktif == "user") || ($aktif == "changepass") || ($aktif == "riwayatdonasi") || ($aktif == "detail_donasi") || ($aktif == "userprofiledit")){ echo "active"; }?>">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo"<i class='fa fa-smile-o'></i> Hi, ".$pengguna; ?><b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li class="<?php if(($aktif == "user") || ($aktif == "userprofiledit")){ echo "active"; }?>"><a href="?module=user">User Profil</a></li>
						<li class="<?php if(($aktif == "riwayatdonasi") || ($aktif == "detail_donasi")){ echo "active"; }?>"><a href="?module=riwayatdonasi">Riwayat Donasi</a></li>
						<li><a href="dir/logout.php" id="logout" onclick="return confirm('Apakah anda yakin untuk keluar?')">Sign out</a></li>
					</ul>
				</li>
			</ul>
		</div>
		
			</ul>
		</div>
			
			
			<!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<!-- Header -->
	<div id="loader"></div>
		
		<!-- /Highlights -->
	<!--BERANDA HOME-->
		<header id="head">
		<div class="container">
					<div class="row">
						<h2>SISTEM INFORMASI<br> KEUANGAN MASJID JAMI AL-MUKHLISIN</h2><br>
						<p class="text-muted"> Menginformasikan Laporan Keuangan Masjid Secara Transparan<br> Ingin menjadi donatur?
						</p>
						<p><a class="btn btn-action btn-lg" href="?module=signup" role="button">DAFTAR DISINI</a></p>

						
					</div>
				</div>
			</header>
			<!-- /Header -->

			<!-- Intro -->
			<div class="container text-center">

				<div class="row">
					<div class="col-md-12 col-sm-6 highlight">
						<div class="h-caption">
							<h3> Laporan Per Tanggal</h3>
							<h5> <b><?php echo $sekarangHari.", ".$sekarang; ?></h5><br>
						</div>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-3 col-sm-6 highlight">
						<div class="h-caption"><h3><i class="fa fa-user fa-5"></i><?php echo $jamaah['jumlah'];?></h3></div>
						<div class="h-body text-center">
							<p> <i>Total Jamaah/Donatur</i> </p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 highlight">
						<div class="h-caption"><h3><i class="fa fa-money fa-5"></i><?php echo "Rp. ".number_format($jumat['saldo'],0,',','.');?></h3></div>
						<div class="h-body text-center">
							<p> <i>Donasi dari para jamaah</i> </p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 highlight">
						<div class="h-caption"><h3><i class="fa fa-users fa-5"></i><?php echo "Rp. ".number_format($jumat['saldo'],0,',','.');?></h3></div>
						<div class="h-body text-center">
							<p> <i>Amal Jumat </i> </p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 highlight">
						<div class="h-caption"><h3><i class="fa fa-archive fa-5"></i><?php echo "Rp. ".number_format($akhir, 0, ',','.');?></h3></div>
						<div class="h-body text-center">
							<p> <i>Saldo Akhir</i> </b></p>
						</div>
					</div>
				</div> <!-- /row  -->
			</div>
			<!-- /Intro-->
				
			<!-- Highlights - jumbotron -->
			<div class="jumbotron top-space">
				<div class="container">
							
					<div class="row">
						<div class="col-md-10 col-sm-12 highlight">
							<div class="h-body text-center">
								<p>
									<i>Dan diriwayatkan dari Abu Hurairah Radhiyallahu ‘Anhu, 
									ia berkata: Rasulullah shallallaahu ‘alaihi wasallam bersabda: 
									<br><b><br>“Barangsiapa bersedekah senilai dengan sebiji Kurma dari penghasilan 
									yang baik (halal) – dan Allah hanya menerima sedekah yang baik (halal) -,
									maka sesungguhnya Allah akan menerima sedekahnya dengan tangan kanan-Nya, 
									kemudian Dia menumbuh-kembangkannya bagi pemiliknya sebagaimana salah seorang 
									dari kamu menumbuh-kembangkan anak kudanya sehingga menjadi seperti (sepenuh) gunung.”</i></b><br>
									<br>(HR. Al-Bukhari II/511 no.1344, dan Muslim II/702 no.1014)
								</p>
							</div>
						</div>
						<div class="col-md-2 col-sm-6 highlight">
							<img src="<?php echo base_url(); ?>assets/front/images/hbjindan.jpg" width="140px" height="170px" class="img-circle" alt="User Image">
						</div>
					</div> <!-- /row  -->
				
				</div>
			</div>
			<div class="container text-justify">
				<div class="container">
							
					<div class="row">
						<div class="col-md-2 col-sm-6 highlight">
							<img src="<?php echo base_url(); ?>assets/front/images/info.png" class="img-circle" alt="User Image">
						</div>
						<div class="col-md-10 col-sm-12 highlight">
							<div class="h-body">
								<p><center><img src="<?php echo base_url(); ?>assets/front/images/login.png" height="80px" class="img-circle" alt="User Image"></center>
									Untuk jamaah/donatur yang ingin melakukan donasi, harap mendaftarkan atau registrasi akun terlebih dahulu untuk dapat login ke sistem informasi keuangan ini.
									Keamanan data dan informasi jamaah/donatur Insya Allah akan terjaga dengan baik.
								</p>
							</div>
						</div>
					</div> <!-- /row  -->
				
				</div>
			</div>


	<!--END BERANDA HOME-->

		<!-- Social links. @TODO: replace by link/instructions in template -->
		<section id="social">
			<div class="container">
				<div class="wrapper clearfix">
					<!-- AddThis Button BEGIN -->
					<div class="addthis_toolbox addthis_default_style">
					<a class="addthis_button_facebook_like" fb:like:layout="button_count"></a>
					<a class="addthis_button_tweet"></a>
					<a class="addthis_button_linkedin_counter"></a>
					<a class="addthis_button_google_plusone" g:plusone:size="medium"></a>
					</div>
					<!-- AddThis Button END -->
				</div>
			</div>
		</section>
		<!-- /social links -->


		<footer id="footer" class="top-space">

			<div class="footer1">
				<div class="container">
					<div class="row">
						
						<div class="col-md-3 widget">
							<h3 class="widget-title">Contact</h3>
							<div class="widget-body">
								<p>+62896 3557 3958<br>
									<a href="mailto:#">novalkrnfds@gmail.com</a><br>
									<br>
									
									
											<br><br><p><a href="adminpage" target="_BLANK">Login Admin Klik Disini</a></p>
										
								</p>	
							</div>
						</div>

						<div class="col-md-3 widget">
							<h3 class="widget-title">Follow me</h3>
							<div class="widget-body">
								<p class="follow-me-icons">
									<a href="http://twitter.com/novalkrnfds" target="_BLANK"><i class="fa fa-twitter fa-2"></i></a>
									<a href="http://instagram.com/novalkrnfds" target="_BLANK"><i class="fa fa-instagram fa-2"></i></a>
									<a href="http://facebook.com/nouval.firdaus" target="_BLANK"><i class="fa fa-facebook fa-2"></i></a>
								</p>	
							</div>
						</div>

						<div class="col-md-6 widget">
							<h3 class="widget-title">SIK MASJID AL-MUKHLISIN</h3>
							<div class="widget-body">
								<p align="justify">Sistem Informasi Keuangan Masjid Jami' Al-Mukhlisin menyajikan informasi data normatif masjid seperti laporan keuangan berupa pemasukan dan pengeluaran, informasi donatur, dhuafa, dll. Sistem Informasi ini diharapkan berguna bagi para jamaah Masjid Jami' Al-Mukhlisin.</p>
								<p align="justify">Sistem Informasi ini dibuat sebagai tugas dari Tugas Akhir. Tidak lupa pula untuk teman-teman REMBES ELITE TEAM saya ucapkan banyak terima kasih yang turut membantu dalam proses pengerjaan project Tugas Akhir ini.</p>
							</div>
						</div>

					</div> <!-- /row of widgets -->
				</div>
			</div>

			<div class="footer2">
				<div class="container">
					<div class="row">
						<div class="pull-right hidden-xs">
							<b>Made with <i class="fa fa-heart"></i> By :</b> <a href="http://facebook.com/nouval.firdaus" target="_BLANK"><strong>Nouval Kurnia Firdaus</strong></a>
						</div>

						<div class="col-md-6 widget">
							<div class="widget-body">
								<p class="text-left">
									<strong>Copyright &copy; <script>document.write(new Date().getFullYear())</script> <a href="">REMBES ELITE TEAM</a></strong> 
								</p>
							</div>
						</div>

					</div> <!-- /row of widgets -->
				</div>
			</div>

		</footer>	
		




	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/front/js/headroom.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/front/js/jQuery.headroom.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/front/js/template.js"></script>
	<script language="javascript" type="text/javascript" src="<?php echo base_url(); ?>assets/front/js/elsyifa.js"></script>
	<script language="javascript" type="text/javascript" src="<?php echo base_url(); ?>assets/front/js/main.js"></script>
	<!-- page script -->
	<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.bootstrap.min.js"></script>
	<script src="adminpage/bootstrap/js/bootstrap-table.js"></script>
	<!-- Google Maps -->
	<script src="https://maps.googleapis.com/maps/api/js?key=&amp;sensor=false&amp;extension=.js"></script> 
	<script src="<?php echo base_url(); ?>assets/front/js/google-map.js"></script>
	<!-- daterangepicker -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
	<script src="adminpage/plugins/daterangepicker/daterangepicker.js"></script>
	<!-- datepicker -->
	<script src="adminpage/plugins/datepicker/bootstrap-datepicker.js"></script>
	
	<script>
		$(function () {
			$("#example1").DataTable();
			$('#example2').DataTable({
			  "paging": true,
			  "lengthChange": false,
			  "searching": false,
			  "ordering": true,
			  "info": true,
			  "autoWidth": false
			});
		});

		function showPage() {
		  document.getElementById("loader").style.display = "none";
		  document.getElementById("myDiv").style.display = "block";
		}
		
		$(document).ready(function () {
			$("#dateFilter").datepicker({ 
				format: "dd MM yyyy",
					autoclose:true
			}).datepicker("setDate", "0");
		});
		
		$(document).ready(function () {
			$("#dateFilter2").datepicker({ 
				format: "dd MM yyyy",
					autoclose:true
			}).datepicker("setDate", "0");
		});
	
	</script>
</body>
</html>