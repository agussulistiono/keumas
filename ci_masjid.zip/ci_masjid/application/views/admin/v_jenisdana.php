
	
<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url();?>">Dana</a>
							</li>
							<li class="active">Dana Masuk</li>
						</ul><!-- /.breadcrumb -->


						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
					
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<?php validation_errors('<span class="error">', '</span>'); ?>
								
										
							
								<?php echo $this->session->flashdata('notif')?>
								<?php echo $this->session->flashdata('berhasil')?>
							
							
							<form class="form-horizontal" action="<?php echo base_url();?>dana/insert_kategori" method="post" >
								<div class="col-xs-5 col-sm-5">
											<div class="widget-box">
												<div class="widget-header">
													<h4 class="widget-title"><?= $subtitle; ?></h4>
										
													<span class="widget-toolbar">
														<a href="#" data-action="settings">
															<i class="ace-icon fa fa-cog"></i>
														</a>
														<a href="#" data-action="reload">
															<i class="ace-icon fa fa-refresh"></i>
														</a>
														<a href="#" data-action="close">
															<i class="ace-icon fa fa-times"></i>
														</a>
													</span>
												</div>
												
												<div class="widget-body">
												<div class="space-4"></div>
													<div class="form-group">
														<label class="col-sm-3 control-label padding-right" for="form-field-1"> Jenis Dana </label>
															<div class="col-sm-9">
															<select class=" col-xs-5 col-sm-5" id="form-field-select-1" name="id_jenis" id="jenis" required="">
															<option value="" selected="selected">----pilih jenis dana---</option>
															<?php foreach($jenis->result() as $data){ ?>
																<option value="<?php echo $data->id_jenis; ?>"><?php echo  $data->jenisdana ?></option>
																<?php
																}
																?>
															</select>
														</div>
													</div>	
													<div class="form-group">
														<label class="col-sm-3 control-label padding-right" for="form-field-1">Kategori</label>
														<div class="col-sm-9">
															<input type="text" id="form-field-1" name="kategori" placeholder="Kategori" id="kategori" class="col-xs-10 col-sm-8"  required="Kategori" />	
														</div>
													</div>

													<div class="clearfix form-actions">
														<div class="col-md-offset-3 col-md-7">
															<button class="btn btn-info" type="submit">
																<i class="ace-icon fa fa-check bigger-110"></i>
																Submit
															</button>

															&nbsp; &nbsp; &nbsp;
															<button class="btn" type="reset">
																<i class="ace-icon fa fa-undo bigger-110"></i>
																Reset
															</button>
														</div>
													</div>
												</div>
											</div>
										</div><!-- /.span -->
								</form>
								<!-- TABEL DATA JENIS-->
								<div class="col-xs-12 col-sm-6 widget-container-col" id="widget-container-col-2">
											<div class="widget-box widget-color-blue" id="widget-box-2">
												<div class="widget-header">
													<h5 class="widget-title bigger lighter">
														<i class="ace-icon fa fa-table"></i>
														Tabel Kaategori Dana
													</h5>

													<div class="widget-toolbar widget-toolbar-light no-border">
														<select id="simple-colorpicker-1" class="hide">
															<option selected="" data-class="blue" value="#307ECC">#307ECC</option>
															<option data-class="blue2" value="#5090C1">#5090C1</option>
															<option data-class="blue3" value="#6379AA">#6379AA</option>
															<option data-class="green" value="#82AF6F">#82AF6F</option>
															<option data-class="green2" value="#2E8965">#2E8965</option>
															<option data-class="green3" value="#5FBC47">#5FBC47</option>
															<option data-class="red" value="#E2755F">#E2755F</option>
															<option data-class="red2" value="#E04141">#E04141</option>
															<option data-class="red3" value="#D15B47">#D15B47</option>
															<option data-class="orange" value="#FFC657">#FFC657</option>
															<option data-class="purple" value="#7E6EB0">#7E6EB0</option>
															<option data-class="pink" value="#CE6F9E">#CE6F9E</option>
															<option data-class="dark" value="#404040">#404040</option>
															<option data-class="grey" value="#848484">#848484</option>
															<option data-class="default" value="#EEE">#EEE</option>
														</select>
													</div>
												</div>

												<div class="widget-body">
													<div class="widget-main no-padding">
														<table id="dynamic-table" class="table table-striped table-bordered table-hover">
															<thead class="thin-border-bottom">
																<tr>
																	<th>No.</th>
																	<th>Jenis Dana</th>
																	<th>Kategori Dana</th>
																	<th>Aksi</th>
																</tr>
															</thead>
															<tbody>
															<?php
															$no=1; 
															foreach($kategori as $d){ ?>
																<tr>
																	<td class=""><?php echo $no++; ?></td>
																	<td class=""><?php echo $d->jenisdana; ?></td>
																	<td class=""><?php echo $d->kategori; ?></td>
																	<td class="hidden-480">
																		<a href="<?php echo base_url('dana/deleteKategori/'.$d->id_kategori );?>">
																			<span class="label label-warning">hapus</span>
																		</a>
																	</td>
																</tr>
															<?php 
															}
															?>
															</tbody>
														</table>
														
													</div>
												</div>
											</div>
										</div><!-- /.span -->
									</div><!-- /.row -->
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

