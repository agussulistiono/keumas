<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_login extends CI_Model {

	public function ceklogin($u, $p)
	{
		$pwd=md5($p);
		$this->db->where('username', $u);
		$this->db->where('password', $pwd);
		$query = $this->db->get('users');
		if($query->num_rows() > 0 ){
			foreach ($query->result() as $row) {
				$sess = array('id_users' =>$row->id_users ,
							  'nama'	 =>$row->nama,
							  'username' =>$row->username,
							  'no_telpon'=>$row->no_telpon,
							  'level'	 =>$row->level,
							  'poto'	 =>$row->poto );

				$this->session->set_userdata($sess);
				return redirect('home');
			}
		}
		else{
			$this->session->set_flashdata('notifikasi','maaf passsword dan username salah');
			redirect('login');
		}

		
	}
}
