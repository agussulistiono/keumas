 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_dana extends CI_Model {

	public function getAll_Transaksi()
	{
		$this->db->select('*')
					->join('jenis_dana','jenis_dana.id_jenis = transaksi.id_jenis')
					->join('kategori_dana','kategori_dana.id_kategori=transaksi.id_users')
					->join('users','users.id_users=transaksi.id_users');
		return $query = $this->db->get('transaksi');
		
	}

	public function code_otomatis(){
            $this->db->select('Right(transaksi.id_transaksi,4) as kode ',false);
            $this->db->order_by('id_transaksi', 'desc');
            $this->db->limit(1);
            $query = $this->db->get('transaksi');
            if($query->num_rows()<>0){
                $data = $query->row();
                $kode = intval($data->kode)+1;//kode otomatis penambahan
            }else{
                $kode = 1;

            }
            $kodemax = str_pad($kode,4,"0",STR_PAD_LEFT);
            $kodejadi  = "T-".$kodemax;
            return $kodejadi;

        }

    public function getjenisdana(){
     	$query = $this->db->get('jenis_dana');
     	return $query;
    }

    public function setkategori(){
        $data = array('id_jenis'=> $this->input->post('id_jenis'),
                       'kategori'=> $this->input->post('kategori'));
        $res = $this->db->insert('kategori_dana', $data);
        if($res>= 1){
            $this->session->set_flashdata("berhasil",'<div class="alert alert-success fade in">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Data Berhasil Di Masukan
                                </div>');
            redirect('dana/getjenisdana');
        }  
    }
    public function getKategori(){
        $this->db->select('*') ->join('jenis_dana', 'jenis_dana.id_jenis = kategori_dana.id_jenis');
        $query= $this->db->get('kategori_dana');
        if($query ->num_rows() > 0){
            foreach ($query->result() as $data ) {
                $kategori[]= $data;
            }
            return $kategori;
        }
    }
    public function delKat($id){
        $this->db->where('id_kategori', $id);
        $this->db->delete('kategori_dana');
    }
}

 