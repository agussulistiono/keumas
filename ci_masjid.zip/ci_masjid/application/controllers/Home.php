<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct(){
		parent::__construct();
	}

	public function index()
	{
		$data['title'] = "SISTEM INFORMASI MASJID ALFURQOR";
		$data['subtitle'] = "Ekasseaf";
		$data['description'] = "home";
		$data['view_isi'] = "view_home";
		$this->load->view('layout/template',$data);
	}

	public function logout(){
		$this->session->session_destroy();
		redirect('home');
	}

	// get berita
	public function halaman(){

	}
	
}
