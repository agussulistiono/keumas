<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$this->load->view('login');
	}

	public function getlogin(){
		$u = $this->input->post('username');
		$p = $this->input->post('password');
		$this->load->model('m_login');
		$this->m_login->ceklogin($u, $p);
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect(base_url('login'));
	}
}
