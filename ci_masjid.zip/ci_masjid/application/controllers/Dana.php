<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dana extends CI_Controller {

	function __construct(){
		parent::__construct();
	}
	public function index()
	{
		$this->load->model('m_dana'); //load mode
		$data['hasil'] 			= $this->m_dana->getAll_Transaksi(); //membuat data dari database
		$data['title'] = "SISTEM INFORMASI MASJID ALFURQOR";
		$data['subtitle'] = "Ekasseaf";
		$data['description'] = "Dana";
		$data['view_isi'] = "admin/v_dana";
		$this->load->view('layout/template', $data);
	}
	public function add_dana()
	{
		$this->load->model('m_dana');
		$data['kodeunik'] = $this->m_dana->code_otomatis();
		$data['title'] = "SISTEM INFORMASI MASJID ALFURQOR";
		$data['subtitle'] = "Ekasseaf";
		$data['description'] = "Dana";
		$data['view_isi'] = "admin/v_add_dana";
		$this->load->view('layout/template', $data);
	}
	public function add_dana_process(){
		$nama				= $this->input->post('nama');
		$alamat				= $this->input->post('alamat');
		$no_hp				= $this->input->post('no_hp');
		$email				= $this->input->post('email');
		$tgl_gabung		= $this->input->post('tgl_gabung');

		$data = array('nama_klien'       => $nama , 
					  'alamat'        	 => $alamat,
					  'no_hp'        	 => $no_hp,
					  'email'   		 => $email,
					  'tgl_gabung'       => $tgl_gabung
			);
		$this->db->insert('tbl_klien',$data);
		redirect('site/lihat_data_klien');
	}
	public function jenisdana(){
		//$this->load->model('m_dana'); //load mode
		//$data['hasilTransaksi'] = $this->m_dana->getAll_Transaksi(); //membuat data dari database
		$data['title'] 			= "SISTEM INFORMASI MASJID ALFURQOR";
		$data['subtitle']	 	= "Kategori";
		$data['description']	= "Dana";
		$data['view_isi'] 		= "admin/v_jenisdana";
		$this->load->view('layout/template', $data);
	}
	public function getjenisdana(){
		$this->load->model('m_dana'); //load mode
		$data['jenis']			= $this->m_dana->getjenisdana(); //membuat data dari database
		$data['kategori']		= $this->m_dana->getKategori();
		$data['title'] 			= "SISTEM INFORMASI MASJID ALFURQOR";
		$data['subtitle']	 	= "Kategori";
		$data['description']	= "Dana";
		$data['view_isi'] 		= "admin/v_jenisdana";
		$this->load->view('layout/template', $data);
	}
	public function insert_kategori(){
		$jenis 		= $this->input->post('id_jenis');
		$kategori 	= $this->input->post('kategori');		
		$data= array('id_jenis' => $jenis,
		             'kategori' => $kategori );
		$this->load->model('m_dana');
		$this->m_dana->setkategori($data);
	}
	public function deleteKategori($id){
		$this->load->model('m_dana','',TRUE); 
        $res = $this->m_dana->delKat($id);
        if ($res <= 1) {
       	$this->session->set_flashdata('notif','<div class="alert alert-success" role="alert"> Data Berhasil dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
       	redirect('dana/getjenisdana');		
		}
	}
	
}